# Santa Carmem Palace Hotel

Landing page institucional em Next.js 14, Tailwind CSS, GSAP, ScrollTrigger e Lenis.

## Rodar localmente
```bash
npm install
npm run dev
```

## Gerar versão estática
```bash
npm run build
```
A exportação estática será criada em `out/`. O conteúdo dessa pasta pode ser publicado em Cloudflare Pages por upload direto.

## Publicação na Cloudflare Pages
1. Execute `npm install` e `npm run build` em um ambiente com Node.js.
2. No painel Cloudflare, abra **Workers & Pages** e selecione **Create application** > **Pages** > **Upload assets**.
3. Envie o conteúdo da pasta `out/` (não a pasta do projeto inteira).
4. Conclua a publicação e configure um domínio, se desejar.

## Observações
- As imagens são carregadas de URLs públicas do Unsplash e precisam de internet.
- Confirme com o hotel a disponibilidade de café da manhã e demais serviços antes de divulgar condições específicas.
- Depoimentos, preços, tipos de quarto e horários não foram inventados nem incluídos.
